Please see our contributor documentation at
https://firefox-source-docs.mozilla.org/testing/geckodriver/geckodriver/#for-developers.
